zip -r release/archive.zip .
